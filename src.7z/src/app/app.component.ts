import { Component } from '@angular/core';
import { pipeBind1 } from '@angular/core/src/render3';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Assignment22';
  Id:number;
  Name:string;
  Salary:number;
  Department:string;
  employee=[
    {Id:121,Name:'krishna',Salary:111,Department:'cse'},
    {Id:123,Name:'pulakanti',Salary:112,Department:'cse'},
    {Id:122,Name:'sai',Salary:115,Department:'cse'},
    {Id:125,Name:'chetan',Salary:112,Department:'cse'},
    {Id:124,Name:'rushan',Salary:110,Department:'cse'},

  ];
  add(eid,ename,esal,edept){
    this.employee.push({Id:eid,Name:ename,Salary:esal,Department:edept});
  }
  sortName(){
    this.employee.sort((p1,p2)=>p1.Name.localeCompare(p2.Name));
  }
}

