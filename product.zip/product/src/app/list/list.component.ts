import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  constructor() { }
  a="right";
 product:Product=new Product;
flag=false;


array:number[]=[2,34,45,12,7,5,0];

  ngOnInit() {
    
  }
  flagMethod(){
    this.flag=!this.flag;
    console.log(this.flag);
  }

}
