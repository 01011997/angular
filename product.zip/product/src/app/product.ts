export class Product{
    id:number=1;
    name:string="qwqw";
    price:number=12300;
}